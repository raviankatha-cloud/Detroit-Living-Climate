import "server-only";
import { createServiceSupabaseClient } from "@/lib/supabase/server";

export type EcobeeIntegrationStatus = {
  apiReady: boolean;
  appKeyConfigured: boolean;
  supabaseConfigured: boolean;
  accountConnected: boolean;
  accountLabel?: string;
  authorizedBy?: string;
  tokenExpiresAt?: string;
  lastSyncAt?: string;
  lastSyncStatus?: string;
  lastSyncMessage?: string;
};

export async function getEcobeeIntegrationStatus(): Promise<EcobeeIntegrationStatus> {
  const supabase = createServiceSupabaseClient();
  const appKeyConfigured = Boolean(process.env.ECOBEE_APP_KEY);

  if (!supabase) {
    return {
      apiReady: false,
      appKeyConfigured,
      supabaseConfigured: false,
      accountConnected: Boolean(process.env.ECOBEE_REFRESH_TOKEN),
      accountLabel: process.env.ECOBEE_REFRESH_TOKEN ? "env refresh token" : undefined
    };
  }

  const [{ data: token }, { data: syncRun }] = await Promise.all([
    supabase
      .from("ecobee_tokens")
      .select("account_label, refresh_token, expires_at, authorized_by, updated_at")
      .eq("account_label", "primary")
      .maybeSingle(),
    supabase
      .from("sync_runs")
      .select("status, message, finished_at, started_at")
      .eq("provider", "ecobee")
      .order("started_at", { ascending: false })
      .limit(1)
      .maybeSingle()
  ]);

  const accountConnected = Boolean(token?.refresh_token || process.env.ECOBEE_REFRESH_TOKEN);

  return {
    apiReady: appKeyConfigured && accountConnected,
    appKeyConfigured,
    supabaseConfigured: true,
    accountConnected,
    accountLabel: token?.account_label ?? (process.env.ECOBEE_REFRESH_TOKEN ? "env refresh token" : undefined),
    authorizedBy: token?.authorized_by ?? undefined,
    tokenExpiresAt: token?.expires_at ? formatDate(token.expires_at) : undefined,
    lastSyncAt: syncRun?.finished_at || syncRun?.started_at ? formatDate(syncRun.finished_at ?? syncRun.started_at) : undefined,
    lastSyncStatus: syncRun?.status ?? undefined,
    lastSyncMessage: syncRun?.message ?? undefined
  };
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit"
  }).format(new Date(value));
}

